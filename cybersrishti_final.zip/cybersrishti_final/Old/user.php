<?php
$mysql_host='localhost';
$mysql_user='id1195412_fest';
$mysql_pass='akshita123';
$mysql_db='id1195412_fest';
if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass)|| !mysql_select_db($mysql_db)){
  die(mysql_error());
}
?>
<!-- ..........................................Fynl.........................................-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cyber Srishti</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Let's Party Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="css/bootstrap1.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style.css" type="text/css" rel="stylesheet" media="all"> 
<link href="css/jquery-ui.css" type="text/css" rel="stylesheet" media="all">
<link href="css/smoothbox.css" type="text/css" rel="stylesheet" media="all">
<link href="css/style1.css" type="text/css" rel="stylesheet" media="all">   
<link href="css/font-awesome.css" rel="stylesheet">		<!-- font-awesome icons -->    
<link rel="stylesheet" href="css/lightbox.css"> 
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /> 
<!-- //Custom Theme files --> 
<!-- js -->
<script src="js/jquery-2.2.3.min.js"></script>  
<!-- //js -->
<!-- web-fonts -->   
<!--<link href="//fonts.googleapis.com/css?family=Trochut:400,400i,700" rel="stylesheet">-->
<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
<!-- //web-fonts -->
<link href="4/thumbs2.css" rel="stylesheet" />
    <link href="4/thumbnail-slider.css" rel="stylesheet" />
    <script src="4/thumbnail-slider.js" type="text/javascript"></script>
</head>
<body id="page-top"  data-spy="scroll" data-target=".navbar-fixed-top"> 








<!--<script src="js/jquery.vide.min.js"></script>
	<div data-img-bg="video/mario.png">-->
		<div class="center-container"  >
			<div class="navigation">
				<div class="container">
					<div class="logo">
						<img src="images/logo.jpg" style="height:50px;width:100px" alt=" " class="img-responsive" />
					</div>
					<div class="navigation-right">
						<span class="menu"><img src="images/menu.png" alt=" " /></span>
						<nav class="link-effect-3" id="link-effect-3">
							<ul class="nav1 nav nav-wil">
<li><a class="page-scroll" href="#home" data-hover="Home">Home</a></li> 
							<li><a class="page-scroll" href="#services" data-hover="Explore">Explore</a></li>

							
<li><a class="page-scroll" href="#about" data-hover="About Us">About Us</a></li>
<!--<li><a class="page-scroll" href="#team" data-hover="Our Team">Our Team</a></li>

							<li><a class="page-scroll" href="#gallery" data-hover="Gallery">Gallery</a></li>-->
<li><a class="page-scroll" href="#contact" data-hover="Contact">Contact</a></li>
<li class="w3ls-navlog"><a class="page-scroll" href="#myModal2" data-toggle="modal" data-hover="Admin">Admin</a></li>
							<!--<li><a class="page-scroll" href="#prices" data-hover="Prices">Prices</a></li>
							<li><a class="page-scroll" href="#blog" data-hover="Blog">Blog</a></li>->
							<li><a class="page-scroll" href="#contact" data-hover="Contact">Contact</a></li>
							<!--<li class="w3ls-navlog"><a class="page-scroll" href="#myModal2" data-toggle="modal" data-hover="LOGIN">LOGIN</a></li>->







<!--





								<li class="active"><a data-hover="Home" href="index.html">Home</a></li>
								<li><a data-hover="About" href="#about" class="scroll">About</a></li>
								<!--<li><a data-hover="Workshop" href="#workshop" class="scroll">Workshop</a></li>
								<li><a data-hover="Talk" href="#talk" class="scroll">Talk</a></li>->
								<li><a data-hover="Accomodation" href="#acc" class="scroll">Accomodation</a></li>
								<li><a data-hover="Student Partner Program" href="#prices" class="scroll">Student Partner Program</a></li>
								<!--<li><a data-hover="Sponsors" href="#sponsors" class="scroll">Sponsors</a></li>->
								<li><a data-hover="Gallery" href="#gallery" class="scroll">Gallery</a></li>
								<li><a data-hover="Contact" href="#contact" class="scroll">Contact</a></li>
							</ul>
						</nav>
							<!-- script-for-menu -->
								<script>
								   $( "span.menu" ).click(function() {
									 $( "ul.nav1" ).slideToggle( 300, function() {
									 // Animation complete.
									  });
									 });
								</script>
							<!-- /script-for-menu -->
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="w3ls_banner_info" >
				<div class="container">
					<!--<div class="w3l_banner_logo">
						<!--<img src="images/logo1.png" alt=" " class="img-responsive" />
					</div>-->
					<center><img src="images/logo.jpg" style="height:250px;width:500px" alt=" " class="img-responsive" />
					<h3>A  2 Day Tech Fest On It For Sustainability</h3>
				<!--	<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
<!-- ..................................................................................................... -->

<!-- timer -->
			<div class="agileits-timer"> 
				<div class="clock">
					<div class="column days">
						<div class="timer" id="days"></div>
						<div class="text">Days</div>
					</div>
					<div class="timer days"></div>
					<div class="column">
						<div class="timer" id="hours"></div>
						<div class="text">Hours</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="minutes"></div>
						<div class="text">Minutes</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="seconds"></div>
						<div class="text">Seconds</div>
					</div>
					<div class="clearfix"> </div>
				</div>	 
			</div>
			<!-- //timer --> 

<!- ..................................................................................................... ->
<br>

					<div class="more">
<a href="events.html" class="hvr-underline-from-center" >Events</a>
					</div>
					<!--modal-video-->
					<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									Schooling
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
								</div>




								<section>
									<div class="modal-body">
										<img src="images/17.jpg" alt=" " class="img-responsive" />
										<p>Ut enim ad minima veniam, quis nostrum 
											exercitationem ullam corporis suscipit laboriosam, 
											nisi ut aliquid ex ea commodi consequatur? Quis autem 
											vel eum iure reprehenderit qui in ea voluptate velit 
											esse quam nihil molestiae consequatur, vel illum qui 
											dolorem eum fugiat quo voluptas nulla pariatur.
											<i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit 
												esse quam nihil molestiae consequatur.</i></p>
									</div>
								</section>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- about -->
















	<!-- banner ->
	<div id="home" class="w3ls-banner w3-agilefireworks jarallax"> 
		<!-- header ->
		<div class="header-w3layouts"> 
			<!-- Navigation ->
			<nav class="navbar navbar-default navbar-fixed-top">
				<div class="container">
					<div class="navbar-header page-scroll">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
							<span class="sr-only"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<img src="images/logo.png" style="height:50px" alt=" " class="img-responsive" />
					</div> 
					<!-- Collect the nav links, forms, and other content for toggling ->
					<div class="collapse navbar-collapse navbar-ex1-collapse">
						<ul class="nav navbar-nav navbar-right cl-effect-15">
							<!-- Hidden li included to remove active class from about link when scrolled up past about section ->
							<li><a class="page-scroll" href="#home" data-hover="Home">Home</a></li> 
							<li><a class="page-scroll" href="#services" data-hover="Our Services">Our Services</a></li>
							<li><a class="page-scroll" href="#team" data-hover="Our Team">Our Team</a></li>
<li><a class="page-scroll" href="#about" data-hover="About Us">About Us</a></li>
							<li><a class="page-scroll" href="#gallery" data-hover="Gallery">Gallery</a></li>
							<!--<li><a class="page-scroll" href="#prices" data-hover="Prices">Prices</a></li>
							<li><a class="page-scroll" href="#blog" data-hover="Blog">Blog</a></li>->
							<li><a class="page-scroll" href="#contact" data-hover="Contact">Contact</a></li>
							<!--<li class="w3ls-navlog"><a class="page-scroll" href="#myModal2" data-toggle="modal" data-hover="LOGIN">LOGIN</a></li>->
						</ul>
					</div>
					<!-- /.navbar-collapse ->
				</div>
				<!-- /.container ->
			</nav>  
		</div>	
		<!-- //header -->
		<!-- banner-text ->
		<div class="banner-text"> 
<center><img src="images/logo1.png" style="height:500px" alt=" " class="img-responsive" />
			<!--<h2>Happy New Year</h2>
			<p>Mauris ex nulla aliquam ornare facilisis nec convallis pulvinar a non nunc non leo sollicitudin, Lorem ipsum dolor sit amet.</p>
			<!-- timer ->
			<div class="agileits-timer"> 
				<div class="clock">
					<div class="column days">
						<div class="timer" id="days"></div>
						<div class="text">Days</div>
					</div>
					<div class="timer days"></div>
					<div class="column">
						<div class="timer" id="hours"></div>
						<div class="text">Hours</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="minutes"></div>
						<div class="text">Minutes</div>
					</div>
					<div class="timer"></div>
					<div class="column">
						<div class="timer" id="seconds"></div>
						<div class="text">Seconds</div>
					</div>
					<div class="clearfix"> </div>
				</div>	 
			</div>
			<!-- //timer -> 
			<a href="#small-dialog" class="wthree-btn popup-with-zoom-anim">Enter the Game </a> 
		</div> 
		<!-- //banner-text ->   
	</div>	
	<!-- //banner --> 
	<!-- welcome -->
	<div class="welcome">    
		<div class="welcome-agileinfo">
			<div class="col-sm-6 col-xs-6 welcome-w3left">
				<div class="col-xs-3 welcome-w3limg">
					<i class="fa fa-calendar-plus-o" aria-hidden="true"></i>
				</div>
				<div class="col-xs-9 welcome-w3ltext"> 
					<p>When</p>
					<h4>22-23 APR 2017</h4>
					<h6>Starting at : 09:00 am </h6><br>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="col-sm-6 col-xs-6 welcome-w3right">
				<div class="col-xs-9 welcome-w3ltext"> 
					<p>Where</p>
					<h4>NOIDA, UP</h4>
					<h6>Jaypee Institute of Information Technology, Sector 62 </h6>
				</div>
				<div class="col-xs-3 welcome-w3limg">
					<i class="fa fa-street-view" aria-hidden="true"></i>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="clearfix"> </div>
		</div> 
	</div>
	<!-- //welcome -->
	<!-- services -->
	<div id="services" class="services">
		<div class="container">  
			<h3 class="w3stitle"><span>EXPLORE</span></h3>  
			<!--<div class="services-w3ls-row">
				<div class="col-md-6 col-sm-6 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-home effect-1" aria-hidden="true"><a href="acc.html"/></span>
					<h5>Accomodation</h5>
					<p>Itaque earum rerum hic a sapiente delectus in auctor sapien.</p>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-list-alt effect-1" aria-hidden="true"><a href="spp.html"/></span>
					<h5>Student Partner Program</h5>
					<p>Itaque earum rerum hic a sapiente delectus in auctor sapien.</p>
				</div>
				<!--<div class="col-md-4 col-sm-4 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-tree-deciduous effect-1" aria-hidden="true"><a href="workshop.html"/></span>
					<h5>Workshop</h5>
					<p>Itaque earum rerum hic a sapiente delectus in auctor sapien.</p>
				</div>
				<!--<div class="col-md-3 col-sm-3 col-xs-6 services-grid">
					<span class="glyphicon glyphicon-globe effect-1" aria-hidden="true"><a href="index1.html"/></span>
					<h5>Talk</h5>
					<p>Itaque earum rerum hic a sapiente delectus in auctor sapien.</p>
				</div> 
				<div class="clearfix"> </div>
			</div>  
		</div>-->
		<div class="container">  
			<!--<h3 class="w3stitle">OUR <span> SERVICES</span></h3> --> 
			<div class="services-w3ls-row">
				<div class="col-md-4 col-sm-4 col-xs-6 services-grid">
					<span class="glyphicon glyphicon-home effect-1" aria-hidden="true"><a href="acc.html"/></span>
					<h5>Accomodation</h5>
					
				</div>
				<div class="col-md-4 col-sm-4 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-picture effect-1" aria-hidden="true"><a href="gallery.html"/></span>
					<h5>Gallery</h5>
					
				</div>
				<div class="col-md-4 col-sm-4 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-list-alt effect-1" aria-hidden="true"><a href="team.html"/></span>
					<h5>Our Team</h5>
					
				</div>
				<!--<div class="col-md-4 col-sm-4 col-xs-6 services-grid agileits-w3layouts">
					<span class="glyphicon glyphicon-home effect-1" aria-hidden="true"><a href="acc.html"/></span>
					<h5>Accomodation</h5>
					
				</div>-->
				
				<div class="clearfix"> </div>
			</div>  
		</div>
	</div>
</div>
	<!-- //services -->
	<!-- video -->
	<div class="video-agileits jarallax">
		<div class="video">
			<div class="container"> 
				<div class="col-md-12 video-left">
					<h3 id="about" class="w3stitle"<!--w3stitle1"><span>ABOUT US</span></h3><br>
 
					<!--<h4>Itaque earum rerum hic tenetur a sapiente delectus reiciendis maiores alias consequatur aut </h4> -->
					<p>Cyber Srishti, the annual technical festival of Jaypee Institute of Information Technology with a motto of stimulating technology, scientific thinking and innovation.

Being one of a kind technical extravaganza with immense diversity and plethora of events for students to showcase their knowledge and talent, the hospitality of the guests is of paramount importance for Team Cyber Srishti. 

Thus, we at cybersrishti, constantly strive towards the satisfaction of everyone. We shall leave no stone unturned in fulfilling the needs of a secure accommodation away from home. Along with our accommodation facility, we also set up a cafeteria for our participants which would serve a variety of cuisines satisfying the needs of every palate. We strive to make your stay comfortable and your experience, a memorable one. Hospitality management would be one of the prime focuseds of Team Cyber Srishti, 2017.</p>
				</div> 
				<!--<div class="col-md-6 video-right"> 
					<a class="play-icon popup-with-zoom-anim" href="#small-dialog2">
						<span class="fa fa-play-circle-o"> </span>
					</a> 
					<div id="small-dialog2" class="mfp-hide">
						<div class="pop_up w3-agile">
							<iframe src="https://www.youtube.com/embed/9JX4hCTuiEw"></iframe>
						</div>   
					</div> -->
				</div>
			</div>
		</div>
	</div>
	<!-- //video -->



<br><br>










<!--............................................................................->

<h3 id="team" class="w3stitle">Our <span> Team</span></h3><br>  
<div id="thumbnail-slider">
            <div class="inner">
                <ul>
                    <li>
                        <a class="thumb" href="images/1.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/2.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/3.jpg"></a>
                    </li>
		    <li>
                        <a class="thumb" href="images/4.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/5.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/6.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/7.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/8.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/9.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/10.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/11.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/2.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/3.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/4.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/5.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/6.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/7.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/8.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/9.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/10.jpg"></a>
                    </li>
                    <li>
                        <a class="thumb" href="images/11.jpg"></a>
                    </li>
                </ul>
            </div>
        </div>
<br>
<!--..................................................................................................-->
























<!-- testimonials ->
	<div class="testimonials team">
		<div class="container">
			<h3 id="team" class="w3stitle">Our <span> Team</span></h3>   
			<div class="flexslider">
				<ul class="slides">
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t5.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Sanjay Goel	- <span>Adipiscing</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t6.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Vestibulum ac odio nec lorem commodo. </p>
								<h4>Manish Kumar Thakur	- <span>Lorem ipsum</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t7.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Shamim Akhtar	- <span>Fusce congue</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
				</ul>
			</div> 
			<!-- FlexSlider js ->
			<script defer src="js/jquery.flexslider.js"></script>
			<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			</script>
			<!-- //FlexSlider js ->
		</div>
	</div>
	<!-- //testimonials -->




	<!-- team ->
	<div id="staff" class="team">  
		<div class="container">  
			<h3 class="w3stitle">OUR <span> Team</span></h3><br><br>
<h4 style="text-align:center; color:red">Faculty Coordinators</h4>  
			<div class="team-agileinfo w3ls-team-row">  
				<div class="col-md-4 col-sm-4 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t1.jpg" alt="img">
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Sanjay Goel</h5>
							<p>Manager</p>
						</div>	 
					</div>    
				</div>
				<div class="col-md-4 col-sm-4 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t2.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Manish Kumar Thakur</h5>
							<p>Event-Manager</p>
						</div>
					</div>    
				</div>
				<div class="col-md-4 col-sm-4	 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t3.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Shamim Akhtar</h5>
							<p>Team Manager</p>
						</div>
					</div>    
				</div>
				<!--<div class="col-md-3 col-sm-3 col-xs-6 team-wthree-grids">   
					<div class="w3ls-effect11">
						<img src="images/t4.jpg" alt="img"> 
						<div class="overlay"> 
							<div class="w3social-icons"> 
								<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
									<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
								</ul>
							</div>   
							<h5>Edward</h5>
							<p>CEO& Founder</p>
						</div>
					</div>    
				</div>->
				<div class="clearfix"> </div> 
			</div>
		</div>
	</div>
	<!-- //team -->






<!-- gallery ->
	<div class="gallery" id="gallery">
		<h3 class="w3stitle">OUR <span> Gallery</span></h3>
		<p class="nostrud">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
		<div class="w3agile_gallery_grids">
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" href="images/8.jpg" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum">
						<figure>
							<img src="images/8.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/9.jpg">
						<figure>
							<img src="images/9.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/10.jpg">
						<figure>
							<img src="images/10.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/11.jpg">
						<figure>
							<img src="images/11.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/12.jpg">
						<figure>
							<img src="images/12.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/13.jpg">
						<figure>
							<img src="images/13.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/14.jpg">
						<figure>
							<img src="images/14.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
			<div class="col-md-3 w3agile_gallery_grid">
				<div class="w3agile_gallery_image">
					<a class="sb" title="quis nostrud exercitation ullamco laboris quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum" href="images/15.jpg">
						<figure>
							<img src="images/15.jpg" alt="" class="img-responsive" />
							<figcaption>
								<h4>dolore magna aliqua</h4>
								<p>
									Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
									tempor incididunt ut labore et dolore magna aliqua.
								</p>
							</figcaption>
						</figure>
					</a>
				</div>
			</div>
		   <div class="clearfix"> </div>
		</div>
		<script type="text/javascript" src="js/smoothbox.jquery2.js"></script>
	</div>
<!-- //gallery -->



























  
	<!-- gallery ->
	<div id="gallery" class="gallery">
		<div class="container"> 
			<h3 class="w3stitle">OUR <span> Gallery</span></h3>  
			<div class="gallery-w3lsrow">
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g1.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g1.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g2.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g2.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g3.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g3.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g4.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g4.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g5.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g5.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g6.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g6.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g7.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g7.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>
				<div class="col-sm-3 col-xs-4 gallery-grids">
					<div class="w3ls-hover">
						<a href="images/g8.jpg" data-lightbox="example-set" data-title="Lorem Ipsum is simply dummy the when an unknown galley of type and scrambled it to make a type specimen.">
							<img src="images/g8.jpg" class="img-responsive zoom-img" alt=""/>
							<div class="view-caption">
								<h5>Latest Gallery</h5>
								<span class="glyphicon glyphicon-search"></span>
							</div>
						</a>
					</div>
				</div>  
				<div class="clearfix"> </div> 
			</div>
			<!--  light box js ->
			<script src="js/lightbox-plus-jquery.min.js"> </script> 
			<!-- //light box js-> 
		</div> 
	</div>
	<!-- //gallery -->
	<!-- prices ->
	<div id="prices" class="prices w3-agilefireworks jarallax">
		<div class="pricesw3-agileits">
			<div class="container"> 
				<h3 class="w3stitle">Our<span> Workshop</span></h3>   
				<div class="prices-agileinfo">
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-two">
							<div class="pricing-top top-two">
								<h3>Workshop 1</h3>
								<p>$50</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Dance Troupe</p> 
								<p>-</p> 
								<p>Fireworks</p> 
								<p class="w3agile">Live Band</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing">
							<div class="pricing-top">
								<h3>Workshop 2</h3>
								<p>$62</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Premium Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p>  
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-three">
							<div class="pricing-top top-three">
								<h3>W4</h3>
								<p>$80</p>
							</div>
							<div class="pricing-bottom wthree"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div> 
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-four">
							<div class="pricing-top top-four">
								<h3>W3</h3>
								<p>$100</p>
							</div>
							<div class="pricing-bottom w3ls"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p>  
								<p>Fireworks</p> 
								<p class="w3agile agileits">Rain Dance</p>  
								<p>Dance Troupe</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div> 
<div class="prices-agileinfo">
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-two">
							<div class="pricing-top top-two">
								<h3>Workshop 1</h3>
								<p>$50</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Dance Troupe</p> 
								<p>-</p> 
								<p>Fireworks</p> 
								<p class="w3agile">Live Band</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing">
							<div class="pricing-top">
								<h3>Workshop 2</h3>
								<p>$62</p>
							</div>
							<div class="pricing-bottom"> 
								<p>Code Dress</p> 
								<p>Premium Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p>  
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div>
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-three">
							<div class="pricing-top top-three">
								<h3>W4</h3>
								<p>$80</p>
							</div>
							<div class="pricing-bottom wthree"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p> 
								<p>Fireworks</p> 
								<p>Dance Troupe</p> 
								<p>Rain Dance</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div> 
					<div class="col-sm-3 col-xs-6 price-w3lgrids">
						<div class="pricing pricing-four">
							<div class="pricing-top top-four">
								<h3>W3</h3>
								<p>$100</p>
							</div>
							<div class="pricing-bottom w3ls"> 
								<p>Code Dress</p> 
								<p>Lavish Buffet</p>  
								<p>Fireworks</p> 
								<p class="w3agile agileits">Rain Dance</p>  
								<p>Dance Troupe</p> 
								<div class="agileits-buy">
									<a class="popup-with-zoom-anim" href="#small-dialog">More Details</a>
								</div>
							</div>
						</div>  
					</div> 
					<div class="clearfix"> </div>  
				</div> 
			</div> 
		</div>
	</div>
	<!-- //prices -->
	<!-- testimonials ->
	<div class="testimonials team">
		<div class="container">
			<!--<h3 class="w3stitle">What <span> People say</span></h3> ->    
			<div class="flexslider">
				<ul class="slides">
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t5.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Douglas Joe	- <span>Adipiscing</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div>
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t6.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Fusce congue tempor nisi sed luctus. Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Vestibulum ac odio nec lorem commodo. </p>
								<h4>Laura Hill	- <span>Lorem ipsum</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
					<li>
						<div class="testi-three-grids"> 
							<div class="testi-left">
								<img src="images/t7.jpg" alt=" " class="img-responsive" />
							</div>
							<div class="testi-right">
								<p>Vestibulum semper quis enim vitae posuere. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce congue tempor nisi sed luctus. Vestibulum ac odio nec lorem commodo. </p>
								<h4>Christopher	- <span>Fusce congue</span></h4> 
							</div>
							<div class="clearfix"> </div>
						</div> 
					</li>
				</ul>
			</div> 
			<!-- FlexSlider js ->
			<script defer src="js/jquery.flexslider.js"></script>
			<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			</script>
			<!-- //FlexSlider js ->
		</div>
	</div>
	<!-- //testimonials -->
	<!-- blog ->
	<div id="blog" class="blog gallery">
		<div class="container">  
			<h3 class="w3stitle"><span> Talks</span></h3>     
			<div class="blog-agileinfo">
				<div class="col-md-7 blog-w3grid-img">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img1.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Soluta vum nobis</a></h4>
					<h6>By <a href="#"> Admin</a> - Nov 25th, 2016 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante in mattis earum rerum delectus in auctor sapien. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="blog-agileinfo blog-agileinfo-mdl">
				<div class="col-md-7 blog-w3grid-img blog-img-rght">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img2.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Aenean nec purus ac</a></h4>
					<h6>By <a href="#"> Admin</a> - Dec 31st, 2015 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante in mattis earum rerum hic a sapiente delectus. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
			<div class="blog-agileinfo">
				<div class="col-md-7 blog-w3grid-img">
					<a href="#myModal" data-toggle="modal" class="wthree-blogimg">  
						<img src="images/img3.jpg" class="img-responsive" alt=""/>
					</a>  
				</div>
				<div class="col-md-5 blog-w3grid-text"> 
					<h4><a href="#myModal" data-toggle="modal">Mattis earum rerum</a></h4>
					<h6>By <a href="#"> Admin</a> - Dec 25th, 2016 </h6>
					<p>Sed interdum interdum accumsan. Aenean nec purus ac orci finibus facilisis. In sit amet placerat nisl, in auctor sapien. Donec ultricies faucibus ante rerum hic a sapiente delectus in auctor sapien. </p>
				</div> 
				<div class="clearfix"> </div>
			</div> 
		</div>
	</div>
	<!-- //blog --> 
	<!-- subscribe ->
	<div class="subscribe wthree-sub jarallax">  
		<div class="subscribe-agileinfo">  
			<div class="container"> 
				<div class="col-sm-6 sub-w3lsleft"> 
					<h3 class="w3stitle">Subscribe <span> Newsletter</span></h3>   
					<p>Sed tincidunt lorem sed velit lacus ornare <a href="">Privacy policy</a>.</p>			
				</div>
				<div class="col-sm-6 sub-w3lsright">
					<form action="#" method="post"> 
						<input type="email" name="email" placeholder="Enter your Email..." required="">
						<input type="submit" value="Subscribe">
						<div class="clearfix"> </div>
					</form>  
				</div>
				<div class="clearfix"></div> 
			</div>
		</div>
	</div>
	<!-- //subscribe -->
	<!-- contact -->
	<div id="contact" class="contact">
		<div class="container"> 
			<h3 class="w3stitle"> <span>Contact us</span></h3>
			<div class="contact-row agileits-w3layouts">  
				<div class="col-md-6 col-sm-6 contact-w3lsleft">
					<div class="contact-grid agileits">
						<h4>DROP US A QUERY </h4>
						<form action="#" method="post"> 
							<input type="text" name="Name" placeholder="Name" required="">
							<input type="email" name="Email" placeholder="Email" required=""> 
							<input type="text" name="Phone Number" placeholder="Phone Number" required="">
							<textarea name="Message" placeholder="Message..." required=""></textarea>
							<input type="submit" value="Submit" >
						</form> 
					</div>
				</div>
				<div class="col-md-6 col-sm-6 contact-w3lsright">
					<!--<h6><span>Sed interdum </span>interdum accumsan nec purus ac orci finibus facilisis.</h6>-->
					<div class="address-row">
						<div class="col-xs-2 address-left">
							<span class="glyphicon glyphicon-home" aria-hidden="true"></span>
						</div>
						<div class="col-xs-10 address-right">
							<h5>Visit Us</h5>
							<p>A-10,Sector 62, Noida</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="address-row w3-agileits">
						<div class="col-xs-2 address-left">
							<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
						</div>
						<div class="col-xs-10 address-right">
							<h5>Mail Us</h5>
							<p><a href="mailto:info@example.com"> info@cybersrishti.org</a></p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="address-row">
						<div class="col-xs-2 address-left">
							<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
						</div>
						<div class="col-xs-10 address-right">
							<h5>Call Us</h5>
							<p>+01 222 333 4444</p>
						</div>
						<div class="clearfix"> </div>
					</div>  
					<!-- map -->
					<div class="map agileits">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.976951297275!2d77.36990431456923!3d28.630452882418595!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce551491b3ce7%3A0x7335d9fcfd4d9db0!2sJaypee+Institute+of+Information+Technology!5e0!3m2!1sen!2sin!4v1488747392475" width="600" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
					</div>
					<!-- //map --> 
				</div>
				<div class="clearfix"> </div>
			</div>	
		</div>	
	</div>
	<!-- //contact --> 
	<!-- features -->
	<div class="features">
		<div class="container">   
			<!--<div class="wthree-features-row">
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-map-marker" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>LOCATION</p>
						<h4>LONDON, UK</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-ticket" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>REMAINING</p>
						<h4>50 Tickets</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-calendar-plus-o" aria-hidden="true"></i>
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>EVENTS</p>
						<h4>20+ Events</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="col-md-3 col-xs-6 features-w3grid">
					<div class="col-xs-4 features-w3lleft">
						<i class="fa fa-users" aria-hidden="true"></i> 
					</div>
					<div class="col-xs-8 features-w3lright"> 
						<p>CUSTOMERS</p>
						<h4>12,000+</h4>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //features -->
	<!-- copy rights start here -->
	<!--<div class="copyw3-agile">-->
		<div class="container"> 
			<!--<div class="w3social-icons footer-w3icons"> 
				<ul>
					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
					<li><a href="#"><i class="fa fa-google-plus"></i></a></li> 
					<li><a href="#"><i class="fa fa-twitter"></i></a></li> 
					<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
				</ul>
			</div>-->
			<p><center>© 2017 Cyber Srishti. All Rights Reserved | Design by  <span>GDG JIIT,NOIDA</span> </p>
		<!--</div>-->
	</div>
	<!-- //copy right end here --> 
	<!-- pop-up-grid -->
	<div id="small-dialog" class="mfp-hide">
		<div class="pop_up w3-agile">
			<div class="payment-online-form-left">
				<form action="#" method="post"> 
					<h4>Account Info</h4>
					<ul>
						<li><input class="text-box-dark" placeholder="First Name" type="text" required=""></li>
						<li><input class="text-box-dark" placeholder="Last Name" type="text" required=""></li>
					</ul>
					<ul>
						<li><input class="text-box-dark" placeholder="Email" type="email" required=""></li>
						<li><input class="text-box-dark" placeholder="Phone Number" type="text" required=""></li> 
					</ul> 
					<ul>  
						<li>
							<label>No of Tickets</label>
							<select class="form-control">
								<option value="1">1 Ticket</option>
								<option value="2">2 Tickets</option>
								<option value="3">3 Tickets</option>
								<option value="4">4 Tickets</option>
								<option value="5">5 Tickets</option>
								<option value="6">More</option>
							</select> 
						</li>
						<li>
							<label>Package</label>
							<select class="form-control"> 
								<option value="1">Classic</option>
								<option value="2">Elite</option>
								<option value="3">Couple</option>
								<option value="4">Special</option> 
							</select>
						</li> 
					</ul>	
					<ul> 
						<li class="w3ls-address"><input class="text-box-dark" placeholder="Address" type="text" required=""></li> 
					</ul>	
					<div class="clearfix"> </div>
					<h4>Payment Method</h4> 
					<ul class="payment-type w3-agile"> 
						<li><span class="col_checkbox">
							<input type="radio" name="payment-method" id="paypal" value="paypal"> 
							<a class="visa" href="#"> </a>
							</span>												
						</li>
						<li>
							<span class="col_checkbox">
								<input type="radio" name="payment-method" id="card" value="card" checked="">
								<a class="paypal" href="#"> </a>
							</span>
						</li>  
					</ul>
					<div class="clearfix"> </div>
					<ul>
						<li><input class="text-box-dark" placeholder="Card Number" type="text" required=""></li>
						<li><input class="text-box-dark" placeholder="Name on card" type="text" required=""></li>
					</ul>
					<ul>
						<li><input class="text-box-dark" placeholder="Expiration Date" type="text" required=""></li>
						<li><input class="text-box-dark" placeholder="Security Code" type="text" required=""></li>
					</ul> 
					<ul class="payment-sendbtns">
						<li><input type="reset" value="Reset"></li>
						<li><input type="submit" value="Process order"></li>
					</ul>
					<div class="clearfix"> </div>
				</form>
			</div>
		</div>
	</div>
	<!-- //pop-up-grid --> 
	<!-- modal -->
	<div class="modal about-modal w3-agileits fade" id="myModal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body">
					<img src="images/img2.jpg" alt=""> 
					<h5>Cras rutrum iaculis enim</h5>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum iaculis enim, non convallis felis mattis at. Donec fringilla lacus eu pretium rutrum. Cras aliquet congue ullamcorper. Etiam mattis eros eu ullamcorper volutpat. Proin ut dui a urna efficitur varius. uisque molestie cursus mi et congue consectetur adipiscing elit cras rutrum iaculis enim, Lorem ipsum dolor sit amet, non convallis felis mattis at. Maecenas sodales tortor ac ligula ultrices dictum et quis urna. Etiam pulvinar metus neque, eget porttitor massa vulputate. </p>
				</div> 
			</div>
		</div>
	</div>
	<!-- //modal -->
	<!-- modal -->
	<div class="modal about-modal w3-agileits fade" id="myModal2" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div> 
				<div class="modal-body login-page "><!-- login-page -->      
					<div class="sap_tabs">
						<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
							<ul class="resp-tabs-list">
								<li class="resp-tab-item" aria-controls="tab_item-0"><span>Login</span></li>
								<li class="resp-tab-item" aria-controls="tab_item-1"><span>Register</span></li> 
							</ul>	 
							<div class="clearfix"> </div>	
							<div class="resp-tabs-container">
								<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
									<div class="agileits-login">
										<form action="#" method="post">
											<input type="text" class="email" name="Email" placeholder="Email" required=""/>
											<input type="password" class="password" name="Password" placeholder="Password" required=""/>
											<div class="wthree-text"> 
												<ul> 
													<li>
														<label class="anim">
															<input type="checkbox" class="checkbox">
															<span> Remember me ?</span> 
														</label> 
													</li>
													<li> <a href="#">Forgot password?</a> </li>
												</ul>
												<div class="clearfix"> </div>
											</div>  
											<div class="w3ls-submit"> 
												<input type="submit" value="LOGIN">  	
											</div>	
										</form>
									</div> 
								</div>
								<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
									<div class="login-top sign-top">
										<div class="agileits-login">
											<form action="#" method="post">
												<input type="text" name="Username" placeholder="Username" required="">
												<input type="text" class="email" name="Email" placeholder="Email" required=""/>
												<input type="password" class="password" name="Password" placeholder="Password" required=""/>	
												<label class="anim">
													<input type="checkbox" class="checkbox">
													<span> I accept the terms of use</span> 
												</label> 
												<div class="w3ls-submit"> 
													<input class="register" type="submit" value="REGISTER">  
												</div>
											</form> 
										</div>  
									</div>
								</div>
							</div>	
						</div>
						<div class="clearfix"> </div>
					</div>   
				</div> <!-- //login-page -->
			</div>
		</div>
	</div>
	<!-- //modal -->  		 
	<!-- fireworks scripts --> 
	<script type="text/javascript" src="js/jquery.fireworks.js"></script>
	<script>	
		setTimeout(function() {
			$('.w3-agilefireworks').fireworks();   
		});
	</script>
	<!-- //fireworks scripts -->
	<!-- timer scripts --> 
	<script type="text/javascript" src=" js/moment.js"></script>
	<script type="text/javascript" src=" js/moment-timezone-with-data.js"></script>
	<script type="text/javascript" src="js/timer.js"></script>
	<!-- //scripts -->  
	<!-- jarallax -->
	<script src="js/jarallax.js"></script>
	<script src="js/SmoothScroll.min.js"></script>
	<script type="text/javascript">
		/* init Jarallax */
		$('.jarallax').jarallax({
			speed: 0.5,
			imgWidth: 1366,
			imgHeight: 768
		})
	</script>
	<!-- //jarallax --> 
	<!-- ResponsiveTabs js -->
	<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true   // 100% fit in a container
			});
		});
	</script>
	<!-- //ResponsiveTabs js --> 
	<!-- Scrolling Nav JavaScript --> 
    <script src="js/scrolling-nav.js"></script>  
	<!-- //fixed-scroll-nav-js --> 
	<!-- pop-up-box -->    
	<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	<script>
		$(document).ready(function() {
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
		});
																		
		});
	</script> 
	<!-- //pop-up-box -->
	<!-- start-smooth-scrolling --> 
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>	
	<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
			
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
	</script>
	<!-- //end-smooth-scrolling -->	 
	<!-- smooth-scrolling-of-move-up -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
	<!-- //smooth-scrolling-of-move-up -->
	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>
</html>
