<?php


if(isset($_SERVER['REQUEST_METHOD'])=="POST")
{

$conn=mysqli_connect("localhost","cyber_srishti","cyber2k17","cyber_srishti");

if(!$conn)
{
	echo "failure";
}

//$event_name=$_POST['event_name'];
$event_name=$_POST['event_name'];
$team_name=$_POST['team_name'];
$college_name=$_POST['college_name'];
$email=$_POST['email'];
$mobile_no=$_POST['mobile_no'];
$year=$_POST['year'];
$member1_name=$_POST['member1_name'];
$member2_name=$_POST['member2_name'];
$member3_name=$_POST['member3_name'];
$member4_name=$_POST['member4_name'];
$member5_name=$_POST['member5_name'];



$query="Insert into registrations(Event_Name,Team_Name,College_Name,Email,Mobile_no,year,member1_name,member2_name,member3_name,member4_name,member5_name) values('$event_name','$team_name','$college_name','$email','$mobile_no','$year','$member1_name','$member2_name','$member3_name','$member4_name','$member5_name');";
$result=mysqli_query($conn,$query);

if($result){
	echo json_encode("success");
}
else echo json_encode("failure");
}
}
?>