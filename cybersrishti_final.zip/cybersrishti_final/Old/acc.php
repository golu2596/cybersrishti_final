<?php


if(isset($_SERVER['REQUEST_METHOD'])=="POST")
{

$conn=mysqli_connect("localhost","cyber_srishti","cyber2k17","cyber_srishti");

if(!$conn)
{
	echo "failure";
}

//$event_name=$_POST['event_name'];
$name=$_POST['name'];
$college_name=$_POST['college_name'];
$email=$_POST['email'];
$mobile_no=$_POST['mobile_no'];
$year=$_POST['year'];

$query="Insert into accomodation(Name,College_Name,Email,Mobile_no,year) values('$name','$college_name','$email','$mobile_no','$year');";
$result=mysqli_query($conn,$query);

if($result){
	echo "<script>alert('Your response have been recorded.');
	window.location.href='acc.html';</script>";
}
}
?>